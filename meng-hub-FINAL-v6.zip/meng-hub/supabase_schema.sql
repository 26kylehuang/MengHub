-- ============================================================
-- MENG HUB 梦 — SUPABASE SCHEMA
-- Run this in the Supabase SQL editor (Dashboard → SQL Editor)
-- ============================================================

-- ── PROFILES ────────────────────────────────────────────────
-- Mirrors auth.users. Auto-created by trigger on signup.
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  email         text,
  full_name     text,
  role          text not null default 'student' check (role in ('student', 'warren', 'admin')),
  created_at    timestamptz default now()
);
alter table public.profiles enable row level security;
create policy "Users can read own profile"    on public.profiles for select using (auth.uid() = id);
create policy "Users can update own profile"  on public.profiles for update using (auth.uid() = id);
create policy "Admins can read all profiles"  on public.profiles for select using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name');
  -- Also create an empty scratchpad
  insert into public.scratchpads (user_id, content) values (new.id, '');
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();


-- ── CURRICULUM ──────────────────────────────────────────────
create table if not exists public.classes (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  description text,
  is_ap       boolean not null default false,
  created_at  timestamptz default now()
);
alter table public.classes enable row level security;
create policy "Anyone authenticated can read classes" on public.classes for select using (auth.role() = 'authenticated');
create policy "Admins can manage classes" on public.classes for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
);

create table if not exists public.units (
  id               uuid primary key default gen_random_uuid(),
  class_id         uuid not null references public.classes(id) on delete cascade,
  title            text not null,
  sequence_order   int  not null default 1,
  created_at       timestamptz default now()
);
alter table public.units enable row level security;
create policy "Authenticated can read units" on public.units for select using (auth.role() = 'authenticated');
create policy "Admins/Warrens can manage units" on public.units for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role in ('admin','warren'))
);

create table if not exists public.lessons (
  id                   uuid primary key default gen_random_uuid(),
  unit_id              uuid not null references public.units(id) on delete cascade,
  title                text not null,
  sequence_order       int  not null default 1,
  is_priority          boolean not null default false,
  preview_text         text,
  lesson_type          text not null default 'lesson'
                         check (lesson_type in ('lesson','lesson_quiz','chapter_quiz','unit_quiz','ap_exam')),
  quiz_time_minutes    int,    -- null = untimed; 45 for AP section, 8 for lesson quiz
  quiz_question_count  int,    -- target questions: 5 lesson, 15 chapter, 30 unit, 55 AP
  created_at           timestamptz default now()
);
alter table public.lessons enable row level security;
create policy "Authenticated can read lessons" on public.lessons for select using (auth.role() = 'authenticated');
create policy "Admins/Warrens can manage lessons" on public.lessons for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role in ('admin','warren'))
);


-- ── CONTENT BLOCKS ──────────────────────────────────────────
-- Each row is one renderable unit: paragraph, math, video, timeline, cloze, quiz question, etc.
create table if not exists public.blocks (
  id                  uuid primary key default gen_random_uuid(),
  lesson_id           uuid not null references public.lessons(id) on delete cascade,
  type                text not null,           -- 'paragraph','heading_2','math','video','image','timeline','cloze'
  content             text,                    -- raw text / LaTeX / URL
  content_json        jsonb,                   -- structured data (quiz, timeline events, etc.)
  caption             text,
  sequence_order      int not null default 1,
  status              text not null default 'pending_review' check (status in ('pending_review','draft','claimed','in_review','published')),
  warren_notes        text,                -- Warren's fact-check notes before publishing
  review_instruction  text,                -- Admin's instruction to AI when pushing back for re-edit
  assigned_warren_id  uuid references public.profiles(id),
  due_date            timestamptz,
  created_at          timestamptz default now()
);
alter table public.blocks enable row level security;
create policy "Authenticated can read published blocks" on public.blocks for select using (
  auth.role() = 'authenticated' and (
    status = 'published'
    or exists (select 1 from public.profiles where id = auth.uid() and role in ('admin','warren'))
  )
);
create policy "Admins/Warrens can manage blocks" on public.blocks for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role in ('admin','warren'))
);


-- ── ZETTELKASTEN CONCEPTS ───────────────────────────────────
create table if not exists public.concepts (
  id           uuid primary key default gen_random_uuid(),
  title        text not null,
  content_json jsonb not null default '[]',   -- array of blocks (same schema as blocks table)
  class_ids    uuid[] not null default '{}',  -- which classes this concept appears in
  created_at   timestamptz default now()
);
alter table public.concepts enable row level security;
create policy "Authenticated can read concepts" on public.concepts for select using (auth.role() = 'authenticated');
create policy "Admins/Warrens can manage concepts" on public.concepts for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role in ('admin','warren'))
);


-- ── SCRATCHPADS ─────────────────────────────────────────────
create table if not exists public.scratchpads (
  user_id      uuid primary key references public.profiles(id) on delete cascade,
  content      text not null default '',
  last_updated timestamptz default now()
);
alter table public.scratchpads enable row level security;
create policy "Users can only access own scratchpad" on public.scratchpads for all using (auth.uid() = user_id);


-- ── QUIZ TELEMETRY ──────────────────────────────────────────
create table if not exists public.user_progress (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  lesson_id    uuid not null references public.lessons(id) on delete cascade,
  score        int  not null check (score between 0 and 100),
  completed_at timestamptz default now()
);
alter table public.user_progress enable row level security;
create policy "Users can read/write own progress" on public.user_progress for all using (auth.uid() = user_id);
create policy "Admins can read all progress" on public.user_progress for select using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
);

create table if not exists public.nemesis_tracker (
  user_id          uuid not null references public.profiles(id) on delete cascade,
  block_id         uuid not null references public.blocks(id) on delete cascade,
  consecutive_fails int not null default 0,
  last_attempted   timestamptz default now(),
  primary key (user_id, block_id)
);
alter table public.nemesis_tracker enable row level security;
create policy "Users can read/write own nemesis data" on public.nemesis_tracker for all using (auth.uid() = user_id);

-- RPC: safely increment fail count (called from Simulator after wrong answer)
create or replace function public.increment_nemesis_fail(p_user_id uuid, p_block_id uuid)
returns void language plpgsql security definer as $$
begin
  insert into public.nemesis_tracker (user_id, block_id, consecutive_fails, last_attempted)
  values (p_user_id, p_block_id, 1, now())
  on conflict (user_id, block_id)
  do update set
    consecutive_fails = public.nemesis_tracker.consecutive_fails + 1,
    last_attempted    = now();
end;
$$;


-- ── FEEDBACK ────────────────────────────────────────────────
create table if not exists public.user_feedback (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid references public.profiles(id) on delete set null,
  block_id     uuid references public.blocks(id) on delete cascade,
  lesson_id    uuid references public.lessons(id) on delete cascade,
  issue_type   text not null check (issue_type in ('wrong_answer','confusing_explanation','typo')),
  resolved     boolean not null default false,
  created_at   timestamptz default now()
);
alter table public.user_feedback enable row level security;
create policy "Anyone authenticated can insert feedback" on public.user_feedback for insert with check (auth.role() = 'authenticated');
create policy "Admins can read/update all feedback" on public.user_feedback for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
);


-- ── BLOG / WARREN DISPATCH ──────────────────────────────────
create table if not exists public.posts (
  id           uuid primary key default gen_random_uuid(),
  title        text not null,
  slug         text not null unique,
  excerpt      text,
  body         text,
  category     text not null default 'Platform Update',
  published    boolean not null default false,
  published_at timestamptz,
  author_id    uuid references public.profiles(id) on delete set null,
  created_at   timestamptz default now()
);
alter table public.posts enable row level security;
create policy "Anyone can read published posts" on public.posts for select using (published = true or auth.role() = 'authenticated');
create policy "Admins/Warrens can manage posts" on public.posts for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role in ('admin','warren'))
);

-- ── INDEXES FOR PERFORMANCE ──────────────────────────────────
create index if not exists idx_units_class_id         on public.units(class_id);
create index if not exists idx_lessons_unit_id        on public.lessons(unit_id);
create index if not exists idx_blocks_lesson_id       on public.blocks(lesson_id);
create index if not exists idx_blocks_status          on public.blocks(status);
create index if not exists idx_nemesis_user_id        on public.nemesis_tracker(user_id);
create index if not exists idx_progress_user_id       on public.user_progress(user_id);
create index if not exists idx_feedback_resolved      on public.user_feedback(resolved);


-- ── LESSON COMPLETIONS ──────────────────────────────────────
-- Added in session 13: tracks when a student marks a lesson as read
create table if not exists public.lesson_completions (
  user_id      uuid not null references public.profiles(id) on delete cascade,
  lesson_id    uuid not null references public.lessons(id) on delete cascade,
  completed_at timestamptz default now(),
  primary key (user_id, lesson_id)
);
alter table public.lesson_completions enable row level security;
create policy "Users manage own completions" on public.lesson_completions
  for all using (auth.uid() = user_id);
create policy "Admins can read all completions" on public.lesson_completions
  for select using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

create index if not exists idx_completions_user_id on public.lesson_completions(user_id);
create index if not exists idx_completions_lesson_id on public.lesson_completions(lesson_id);


-- ── MIGRATION: Add pending_review status + warren_notes (session 15) ──────
-- Run these if you already have the blocks table deployed:
-- alter table public.blocks drop constraint if exists blocks_status_check;
-- alter table public.blocks add constraint blocks_status_check
--   check (status in ('pending_review','draft','claimed','in_review','published'));
-- alter table public.blocks alter column status set default 'pending_review';
-- alter table public.blocks add column if not exists warren_notes text;

-- Add review_instruction column (session 15+):
-- alter table public.blocks add column if not exists review_instruction text;

-- Add class_ids to concepts for class-priority search filtering (session 18):
-- alter table public.concepts add column if not exists class_ids uuid[] default '{}';
-- create index if not exists idx_concepts_class_ids on public.concepts using gin(class_ids);
-- When a concept is used in a lesson, its class_id should be in class_ids.
-- The extract-concepts API auto-populates this when given a class_id context.

-- ── LESSON TYPES (session 19) ────────────────────────────────
-- lesson_type controls how the lesson is displayed and what quiz experience it gets
-- alter table public.lessons add column if not exists lesson_type text not null default 'lesson'
--   check (lesson_type in ('lesson','lesson_quiz','chapter_quiz','unit_quiz','ap_exam'));
-- alter table public.lessons add column if not exists quiz_time_minutes int; -- null = untimed
-- alter table public.lessons add column if not exists quiz_question_count int; -- target Q count
-- create index if not exists idx_lessons_type on public.lessons(lesson_type);

-- ── FEEDBACK IMPROVEMENTS (session 20) ───────────────────────
-- alter table public.user_feedback add column if not exists note text;
-- alter table public.user_feedback add column if not exists page_url text;
-- alter table public.user_feedback drop constraint if exists user_feedback_issue_type_check;
-- alter table public.user_feedback add constraint user_feedback_issue_type_check
--   check (issue_type in ('wrong_answer','confusing_explanation','typo','factual_error','broken_math','other'));
