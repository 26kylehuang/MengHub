"""
Meng Hub 梦 — Academic Archivist
3-Loop offline ingestion pipeline: Gemini OCR → Claude Structurer → GPT-4o Auditor

Usage:
    export OPENROUTER_API_KEY="sk-or-v1-..."
    export PUBLIC_SUPABASE_URL="https://your-project.supabase.co"
    export SUPABASE_SERVICE_ROLE_KEY="your-service-role-key"
    python academic_archivist.py
"""

import os
import json
import sys
import requests
from supabase import create_client, Client

# ── Configuration ────────────────────────────────────────────
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY")  # No VITE_ prefix
SUPABASE_URL       = os.environ.get("PUBLIC_SUPABASE_URL")
SUPABASE_KEY       = os.environ.get("SUPABASE_SERVICE_ROLE_KEY")  # Service role bypasses RLS

if not all([OPENROUTER_API_KEY, SUPABASE_URL, SUPABASE_KEY]):
    print("❌ Missing environment variables. Set OPENROUTER_API_KEY, PUBLIC_SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY.")
    sys.exit(1)

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

LOOP2_SYSTEM = """You are the Meng Hub Archivist. Convert this academic text into a JSON object with a "blocks" array.

Block schemas:
{"type":"heading_2","content":"..."}
{"type":"paragraph","content":"...wrap key terms in [[Term|uuid]] if known..."}
{"type":"math","content":"LaTeX without $ signs","caption":"optional"}
{"type":"tip","title":"optional","content":"mnemonic or exam warning"}
{"type":"timeline","title":"...","orientation":"horizontal|vertical","events":[{"year":"...","title":"...","desc":"..."}]}
{"type":"table","title":"...","headers":["A","B"],"rows":[["val","val"]]}
{"type":"chart","title":"...","headers":["X","Y"],"rows":[["v","v"]],"caption":"..."}
{"type":"proof","title":"...","steps":[{"statement":"...","reason":"..."}],"conclusion":"..."}
{"type":"cloze","prefix_text":"...","answer":"single word","suffix_text":"..."}
{"type":"frq","stimulus":"Question","points":4,"parts":[{"prompt":"(A)...","model_answer":"...","scoring_guide":"1pt for..."}]}
{"type":"quiz","question_text":"...","options":["A","B","C","D"],"correct_index":0,"explanation":"Why A right","why_wrong":"Why others wrong","topic":"...","hint":"..."}
{"type":"summary","title":"...","points":["takeaway 1"],"concept_questions":[{"question":"Why did X cause Y?","type":"Cause & Effect","answer":"Deep explanation"},{"question":"How does X connect to Z?","type":"Connection","answer":"..."}]}

Rules: use tip for mnemonics/warnings, use vertical timeline for processes, end EVERY lesson with a summary block with 3+ deep concept questions (cause/effect, connections, counterfactuals — NOT simple recall).
Output ONLY: {"blocks": [...], "suggested_lesson_title": "..."}"""

LOOP3_SYSTEM = """You are a rigorous AP exam content auditor. Review these JSON blocks and:
1. Fix ALL broken LaTeX (test mentally against KaTeX — no \\text{} in math mode, etc.)
2. Every quiz block MUST have a detailed explanation AND why_wrong covering each wrong option
3. Flag any factual inaccuracies in issues_fixed
4. Ensure cloze answers are single words or short phrases only
Output corrected JSON: {"blocks": [...], "issues_fixed": ["list of what you changed"]}"""


def call_openrouter(model: str, system: str, content: str) -> dict:
    resp = requests.post(
        "https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://menghub.com",
            "X-Title": "Meng Hub Archivist",
        },
        json={
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user",   "content": content},
            ],
            "response_format": {"type": "json_object"},
        },
        timeout=120,
    )
    resp.raise_for_status()
    raw = resp.json()["choices"][0]["message"]["content"]
    return json.loads(raw)


def get_current_max_order(lesson_id: str) -> int:
    result = supabase.table("blocks") \
        .select("sequence_order") \
        .eq("lesson_id", lesson_id) \
        .order("sequence_order", desc=True) \
        .limit(1) \
        .execute()
    rows = result.data
    return rows[0]["sequence_order"] if rows else 0


def process_textbook_scan(raw_ocr_text: str, target_lesson_id: str) -> None:
    print("🚀 Starting 3-Loop Archival Process...")

    # Load existing concepts for [[link]] injection
    concepts_result = supabase.table("concepts").select("id, title").execute()
    concept_map = "\n".join([f"- [[{c['title']}|{c['id']}]]" for c in (concepts_result.data or [])])
    concept_context = f"\n\nKNOWN CONCEPTS (use exact UUIDs when writing [[links]]):\n{concept_map}" if concept_map else ""

    # ── Loop 1: Gemini — OCR cleanup ────────────────────────
    print("🔁 Loop 1: Gemini fixing curves and OCR noise...")
    loop1_prompt = (
        "You are an academic transcriber. Fix curved-spine distortion, OCR errors, "
        "and broken math from this raw scanned text. Output clean prose as JSON: {\"text\": \"...\"}"
    )
    loop1_result = call_openrouter("google/gemini-pro-1.5", loop1_prompt, raw_ocr_text)
    clean_text = loop1_result.get("text", raw_ocr_text)
    print(f"   ✓ Clean text: {len(clean_text)} chars")

    # ── Loop 2: Claude — Structure into blocks ───────────────
    print("🔁 Loop 2: Claude structuring into Meng Hub blocks...")
    loop2_result = call_openrouter("anthropic/claude-3.5-sonnet", LOOP2_SYSTEM + concept_context, clean_text)
    draft_blocks = loop2_result.get("blocks", [])
    print(f"   ✓ {len(draft_blocks)} blocks generated")

    # ── Loop 3: GPT-4o — Audit LaTeX + quiz logic ───────────
    print("🔁 Loop 3: GPT-4o auditing LaTeX and quiz explanations...")
    loop3_result = call_openrouter("openai/gpt-4o", LOOP3_SYSTEM, json.dumps({"blocks": draft_blocks}))
    final_blocks = loop3_result.get("blocks", draft_blocks)
    issues = loop3_result.get("issues_fixed", [])
    if issues:
        print(f"   ✓ Fixed {len(issues)} issue(s): {'; '.join(issues[:3])}")
    print(f"   ✓ {len(final_blocks)} blocks audited")

    # ── Step 4: Inject into Supabase ────────────────────────
    print("💾 Uploading validated blocks to Supabase (status=draft)...")
    start_order = get_current_max_order(target_lesson_id) + 1

    rows = []
    for i, block in enumerate(final_blocks):
        btype = block.get("type", "paragraph")
        # Quiz/timeline/cloze go into content_json as plain objects
        # Paragraph/heading/math go into the content text field
        is_structured = btype in ("quiz", "timeline", "cloze")
        rows.append({
            "lesson_id":      target_lesson_id,
            "sequence_order": start_order + i,
            "type":           btype,
            "content":        None if is_structured else block.get("content"),
            "content_json":   block if is_structured else None,
            "caption":        block.get("caption"),
            "status":         "pending_review",  # Admin reviews before Warren job board
        })

    result = supabase.table("blocks").insert(rows).execute()
    print(f"✅ Archival Complete! {len(rows)} blocks saved to lesson {target_lesson_id[:8]}...")
    return result


# ── CLI entrypoint ───────────────────────────────────────────
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python academic_archivist.py <lesson_id> <path_to_text_file>")
        print("  OR:  python academic_archivist.py <lesson_id> --stdin")
        sys.exit(1)

    lesson_id = sys.argv[1]
    if sys.argv[2] == "--stdin":
        raw_text = sys.stdin.read()
    else:
        with open(sys.argv[2], "r", encoding="utf-8") as f:
            raw_text = f.read()

    process_textbook_scan(raw_text, lesson_id)
