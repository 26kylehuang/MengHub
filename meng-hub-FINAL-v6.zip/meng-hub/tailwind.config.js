/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{html,js,svelte,ts}'],
  theme: {
    extend: {
      fontFamily: {
        // UI Font: Crisp, modern tracking for sidebars and dashboards
        sans: ['Inter', 'system-ui', 'sans-serif'],
        // Reading Font: Academic, library-style serif for the actual notes
        serif: ['Merriweather', 'Georgia', 'serif'],
        // Monospace: For tags, blocks, and fallback code
        mono: ['Fira Code', 'monospace']
      },
      colors: {
        // Custom "Space/Dream" color palette
        cosmos: {
          900: '#0B0F19',     // Deepest space background
          800: '#111827',     // Slightly lighter for navbar
          700: '#1F2937',     // Borders and dividers
        },
        // Custom "Library Archive" color palette for the reading panes
        archive: {
          bg: '#FAFAFA',      // Crisp off-white for reading comfort
          paper: '#FFFFFF',   // Pure white for cards/modals
          ink: '#334155',     // Slate-700 text (easier on eyes than pure black)
          highlight: '#E0F2FE'// Light blue for Zettelkasten hovers
        }
      },
      animation: {
        // Animations for the floating class/unit bubbles
        'float-slow': 'float 6s ease-in-out infinite',
        'float-medium': 'float 4s ease-in-out infinite',
        'pulse-glow': 'pulseGlow 3s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0) scale(1)' },
          '50%': { transform: 'translateY(-12px) scale(1.02)' },
        },
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(59,130,246,0.3)' },
          '50%': { boxShadow: '0 0 50px rgba(59,130,246,0.6)' },
        }
      }
    }
  },
  plugins: []
};
