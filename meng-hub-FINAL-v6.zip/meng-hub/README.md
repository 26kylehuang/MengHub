# Meng Hub 梦

A high-fidelity cognitive learning ecosystem replacing messy textbooks. Active Recall + Zettelkasten + Spaced Repetition, built on SvelteKit + Supabase + Cloudflare.

## Stack

| Layer | Tech |
|---|---|
| Frontend | SvelteKit, TypeScript, Tailwind CSS |
| Backend / Auth | Supabase (PostgreSQL, RLS, Auth) |
| Hosting | Cloudflare Pages |
| Storage | Cloudflare R2 |
| AI | OpenRouter (Gemini, Claude, GPT-4o) |
| Math | KaTeX (auto-render) |

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Environment variables
Create a `.env` file:
```
PUBLIC_SUPABASE_URL=https://your-project.supabase.co
PUBLIC_SUPABASE_ANON_KEY=your-anon-key
OPENROUTER_API_KEY=your-openrouter-key
```

For Cloudflare Pages, add these in **Settings → Environment Variables**.

### 3. Database
Run `supabase_schema.sql` in the Supabase SQL editor. This creates all tables, RLS policies, indexes, triggers, and the `increment_nemesis_fail` RPC.

### 4. Dev server
```bash
npm run dev
```

### 5. Deploy
```bash
npm run build
```
Push to GitHub and connect to Cloudflare Pages. Build command: `npm run build`. Output: `.svelte-kit/cloudflare`.

## Roles

| Role | Access |
|---|---|
| `student` | Read published content, take quizzes, manage scratchpad |
| `warren` | All student access + Warren job board + Content Forge |
| `admin` | Everything + Admin Mission Control + user management |

Set roles in Supabase: `update profiles set role = 'admin' where email = 'you@example.com';`

## Key Features

- **Tri-pane lesson reader** — nav accordion / notes / spotlight + scratchpad
- **Zettelkasten links** — `[[Concept Name|uuid]]` syntax lazy-loads definitions on hover
- **Active Recall Quiz** — blurs notes, A/B/C/D keyboard shortcuts, guided/strict modes
- **Nemesis Engine** — tracks wrong answers, surfaces them as spaced repetition drills
- **AI Content Forge** — 3-loop pipeline (Gemini OCR → Claude structurer → GPT-4o auditor)
- **Warren job board** — claim/publish AI-generated draft blocks
- **Right-click feedback** — any block reports a typo/error directly to admin inbox

## Content Block Schema

Blocks are stored in the `blocks` table with a `type` field:

```json
{ "type": "paragraph", "content": "Text with [[Concept|uuid]] links." }
{ "type": "heading_2", "content": "Section Title" }
{ "type": "math", "content": "\\int_{a}^{b} f(x)\\,dx", "caption": "optional" }
{ "type": "video", "url": "https://youtube.com/embed/..." }
{ "type": "timeline", "title": "...", "events": [{"year":"1945","title":"...","description":"..."}] }
{ "type": "cloze", "prefix_text": "The capital is", "answer": "Paris", "suffix_text": "." }
```

Quiz blocks go in `content_json`:
```json
{
  "question_text": "What did the Truman Doctrine pledge?",
  "options": ["Contain Soviet expansion", "Build the Berlin Wall", "Fund the Marshall Plan", "Create NATO"],
  "correct_index": 0,
  "explanation": "The Truman Doctrine (1947) pledged US support to nations threatened by Soviet expansion.",
  "why_wrong": "The Marshall Plan (C) was economic aid, announced separately.",
  "topic": "Cold War Origins",
  "hint": "Think about what 'doctrine' means in foreign policy."
}
```
