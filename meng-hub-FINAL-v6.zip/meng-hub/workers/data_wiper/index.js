/**
 * Meng Hub 梦 — Nightly Maintenance Worker
 * Runs on a Cloudflare Cron schedule (e.g. 0 3 * * * = 3am UTC daily)
 *
 * Bind the following secrets in your Cloudflare Worker settings:
 *   SUPABASE_URL            = your project URL
 *   SUPABASE_SERVICE_ROLE_KEY = service role key (bypasses RLS)
 */

import { createClient } from '@supabase/supabase-js';

export default {
    async scheduled(event, env, ctx) {
        const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);
        const results = [];

        console.log('🧹 Meng Hub nightly maintenance starting...');

        // 1. Purge resolved feedback older than 30 days
        try {
            const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
            const { count, error } = await supabase
                .from('user_feedback')
                .delete({ count: 'exact' })
                .eq('resolved', true)
                .lt('created_at', cutoff);
            if (error) throw error;
            results.push(`✓ Purged ${count ?? 0} old resolved feedback entries`);
        } catch (e) {
            results.push(`✗ Feedback purge failed: ${e.message}`);
        }

        // 2. Orphan block cleanup — draft blocks not claimed in 14 days
        try {
            const cutoff = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString();
            const { count, error } = await supabase
                .from('blocks')
                .delete({ count: 'exact' })
                .eq('status', 'draft')
                .is('assigned_warren_id', null)
                .lt('created_at', cutoff);
            if (error) throw error;
            results.push(`✓ Purged ${count ?? 0} stale unclaimed draft blocks`);
        } catch (e) {
            results.push(`✗ Draft block purge failed: ${e.message}`);
        }

        // 3. Reset nemesis streaks for users inactive > 60 days
        // (Prevents phantom fails from discouraging returning students)
        try {
            const cutoff = new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString();
            const { count, error } = await supabase
                .from('nemesis_tracker')
                .update({ consecutive_fails: 0 })
                .lt('last_attempted', cutoff)
                .gt('consecutive_fails', 0);
            if (error) throw error;
            results.push(`✓ Reset nemesis streaks for ${count ?? 0} inactive entries`);
        } catch (e) {
            results.push(`✗ Nemesis reset failed: ${e.message}`);
        }

        console.log('🧹 Maintenance complete:\n' + results.join('\n'));
        return new Response(results.join('\n'), { status: 200 });
    },
};
