/// <reference types="svelte" />
/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly PUBLIC_SUPABASE_URL: string;
  readonly PUBLIC_SUPABASE_ANON_KEY: string;
  // OPENROUTER_API_KEY is server-only ($env/static/private) — not declared here
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
