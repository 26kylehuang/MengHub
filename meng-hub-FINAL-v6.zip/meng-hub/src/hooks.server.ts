import { createServerClient } from '@supabase/ssr';
import { redirect, type Handle } from '@sveltejs/kit';
import { PUBLIC_SUPABASE_URL, PUBLIC_SUPABASE_ANON_KEY } from '$env/static/public';

export const handle: Handle = async ({ event, resolve }) => {
    // 1. Create the secure Server-Side Supabase client
    event.locals.supabase = createServerClient(
        PUBLIC_SUPABASE_URL,
        PUBLIC_SUPABASE_ANON_KEY,
        {
            cookies: {
                getAll: () => event.cookies.getAll(),
                setAll: (cookiesToSet) => {
                    cookiesToSet.forEach(({ name, value, options }) => {
                        event.cookies.set(name, value, { ...options, path: '/' });
                    });
                }
            }
        }
    );

    // 2. Grab the session explicitly
    const { data: { session } } = await event.locals.supabase.auth.getSession();
    event.locals.session = session;

    // 3. Determine Role (Student, Warren, Admin)
    if (session) {
        // Fetch role from the profiles table we made in SQL
        const { data: profile } = await event.locals.supabase
            .from('profiles')
            .select('role')
            .eq('id', session.user.id)
            .single();
        
        event.locals.userRole = profile?.role || 'student';
    } else {
        event.locals.userRole = null;
    }

    // 4. THE ROUTER GUARD (Role-Based Access Control)
    const path = event.url.pathname;

    // Protect Admin routes
    if (path.startsWith('/admin') || path.startsWith('/review')) {
        if (!session) throw redirect(303, '/auth');
        if (event.locals.userRole !== 'admin') throw redirect(303, '/');
    }

    // Protect Warren routes
    if (path.startsWith('/warren')) {
        if (!session) throw redirect(303, '/auth');
        if (event.locals.userRole === 'student') throw redirect(303, '/');
    }

    // Protect authenticated-only routes
    const protectedRoutes = ['/dashboard', '/progress', '/quiz', '/class', '/blog', '/forge', '/profile', '/review', '/warren', '/concepts'];
    if (protectedRoutes.some(r => path.startsWith(r))) {
        if (!session) throw redirect(303, '/auth');
    }

    // 5. Render the page safely
    return resolve(event, {
        filterSerializedResponseHeaders(name) {
            return name === 'content-range' || name === 'x-supabase-api-version';
        },
    });
};
