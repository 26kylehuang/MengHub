import { error, redirect } from '@sveltejs/kit';

export const load = async ({ locals: { supabase, session } }) => {
    // 1. Security Check
    if (!session) throw redirect(303, '/auth');

    // 2. Query the Nemesis Tracker
    // We join the tracker table with the actual blocks table to get the Quiz JSON
    const { data: nemesisData, error: dbError } = await supabase
        .from('nemesis_tracker')
        .select(`
            consecutive_fails,
            blocks!inner(
                id,
                lesson_id,
                content_json
            )
        `)
        .eq('user_id', session.user.id)
        .gt('consecutive_fails', 0) // Only grab active weaknesses
        .order('consecutive_fails', { ascending: false }) // Hardest questions first
        .limit(20); // Give them a maximum 20-question drill

    if (dbError) {
        console.error("Nemesis Fetch Error:", dbError);
        throw error(500, "Failed to load the Nemesis Queue.");
    }

    if (!nemesisData || nemesisData.length === 0) {
        // Queue is clear! Send them back to the dashboard.
        throw redirect(303, '/progress?status=cleared');
    }

    // 3. Extract quiz data from blocks — content_json is a plain object on quiz blocks
    const extractedQuestions = nemesisData
        .map(row => {
            const cj = row.blocks.content_json;
            const quizData = Array.isArray(cj) ? cj[0] : cj;
            // Accept both MCQ (question_text) and FRQ (parts)
            if (!quizData?.question_text && !quizData?.parts) return null;
            return {
                ...quizData,
                block_id: row.blocks.id,
                lesson_id: row.blocks.lesson_id,
                difficulty: row.consecutive_fails
            };
        })
        .filter(Boolean);

    return {
        questions: extractedQuestions
    };
};
