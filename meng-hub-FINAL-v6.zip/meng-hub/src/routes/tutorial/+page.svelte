<script lang="ts">
    import { fade, fly } from 'svelte/transition';
    import { goto } from '$app/navigation';
    import { page } from '$app/stores';

    $: role = $page.data.userRole ?? 'student';

    const studentSteps = [
        {
            icon: '🌌',
            title: 'Welcome to Meng Hub 梦',
            subtitle: 'The Dream Archive',
            body: `Meng Hub replaces your textbook. Everything is here: structured notes, interactive visuals, practice quizzes, and a memory system that tracks exactly what you struggle with.

This tour takes 3 minutes and will make everything click.`,
            tip: null,
        },
        {
            icon: '📖',
            title: 'The Three-Pane Reading View',
            subtitle: 'Zero wasted space',
            body: `Every lesson opens in three columns:

① LEFT — Chapter navigation. See all lessons and quizzes in the unit. Click any lesson to jump there. Your current position is highlighted in blue.

② CENTER — Your notes. Scroll through block-based content: text, math equations, timelines, videos, tables, and proofs.

③ RIGHT — The Spotlight. When you scroll past a video or diagram, it pins there so you can watch while reading. When you hover a concept link, the definition appears here.`,
            tip: '💡 Use ← → arrow keys to jump between lessons without lifting your hands from the keyboard.',
        },
        {
            icon: '🌐',
            title: 'Zettelkasten Concept Links',
            subtitle: 'The most important feature',
            body: `Throughout your notes, you\'ll see terms underlined with a dashed blue line — like Treaty of Versailles or Newton\'s Second Law.

Hover over any of them. A definition card pops up immediately, sourced from the Meng Hub concept archive. The same definition also appears in the right-side Spotlight so it never blocks the text you\'re reading.

You can also search concepts manually using the "🌐 Look up a concept" button in the right pane — it auto-filters to your current class first.`,
            tip: '💡 If a term isn\'t linked yet, search it in the concept panel. If it\'s missing entirely, use the feedback right-click menu to report it.',
        },
        {
            icon: '✏️',
            title: 'Practice Quizzes After Every Lesson',
            subtitle: 'Active recall, not passive reading',
            body: `At the end of every lesson, you\'ll see a Practice Quiz button. Click it — the notes blur out to stop you from cheating yourself.

The quiz replaces the right pane. You get two modes:

① GUIDED — Shows a hint button before you answer. If you get it wrong, the Root-Cause Analyzer pauses and asks: "Why did you fail?" (Misread? Vocab gap? Bad logic?) Then it shows a deep explanation. This forces you to actually understand, not just memorize.

② AP STRICT — No hints. A per-question timer runs. Explanations are locked until you finish the whole drill. This simulates real exam pressure.

Switch modes with the toggle in the top-right corner of the quiz.`,
            tip: '💡 Use keyboard shortcuts: press A, B, C, or D to select an answer. Press Enter to submit. Much faster than clicking.',
        },
        {
            icon: '📋',
            title: 'Quiz Tiers: Lesson → Chapter → Unit → AP Exam',
            subtitle: 'Spaced practice at every level',
            body: `The quiz system has four tiers, shown in the left nav with icons:

✏️ Lesson Check — 5-10 questions, ~8 min. Appears after every lesson. Tests just what you read.

📋 Chapter Quiz — 15 questions, ~20 min. Appears after a group of related lessons. Pulls questions from all those lessons.

🎯 Unit Exam — 30 questions, ~45 min. Covers an entire unit. Like a real unit test.

🏆 AP Practice Exam — 55 MCQ + FRQs, full time limit. Simulates the exact AP exam structure. No hints. Strict timer.

These are actual lessons in the curriculum, placed by the AI at the right points.`,
            tip: '💡 The chapter and unit quizzes pull questions from all the lessons they cover — so the more lessons you read, the more questions appear.',
        },
        {
            icon: '⚔️',
            title: 'The Nemesis Engine',
            subtitle: 'Your personal weakness tracker',
            body: `Every time you get a question wrong, it gets logged. Every time you get it right, its fail count resets.

Your Command Center (📊) shows how many concepts are in your "Nemesis Queue" — these are your hardest repeated misses.

The Nemesis Engine page (🧠) shows each one with red dots indicating how many times you\'ve failed it. Click "⚔️ Conquer Now" to run a custom drill built exclusively from your failures, sorted from worst to least bad.

This is spaced repetition, automated. You never have to think about what to review — the system knows.`,
            tip: '💡 The Nemesis queue also appears on your dashboard with a big "Conquer" button. Check it before every study session.',
        },
        {
            icon: '📝',
            title: 'Your Personal Scratchpad',
            subtitle: 'Private notes, always synced',
            body: `The floating "📝 Personal Notes" button in the right pane opens a private scratchpad drawer.

It auto-saves to your account every 1.5 seconds. It also saves to your browser\'s local storage instantly, so even if you lose connection, nothing is lost.

Your notes are completely private — nobody else can read them, not even admins.`,
            tip: '💡 Use the Scratchpad for your own summaries, memory tricks, or questions to ask later.',
        },
        {
            icon: '🔍',
            title: 'Search Everything',
            subtitle: '⌘K from anywhere',
            body: `Press ⌘K (Mac) or Ctrl+K (Windows/Linux) from anywhere in the app to open the Search Archive.

Type any term and it searches:
• Concepts — definitions, with your current class shown first
• Lessons — jump anywhere in the curriculum instantly

Results from your current class are highlighted with a star ⭐. Results from other classes appear below.`,
            tip: '💡 You can also right-click on any block to report an error — the exact block ID routes directly to the admin inbox.',
        },
        {
            icon: '🎉',
            title: 'You\'re Ready',
            subtitle: 'Let\'s start learning',
            body: `You now know everything you need. Here\'s the recommended flow:

1. Open a lesson from the class dashboard
2. Read through the notes, hovering concept links
3. At the end, mark it as read ✓
4. Take the lesson quiz (guided mode to start)
5. After a few lessons, do the chapter quiz
6. Check your Nemesis queue regularly

The system gets smarter the more you use it. The more you struggle with something, the more the Nemesis Engine prioritizes it for you.

Good luck. You\'ve got this.`,
            tip: null,
        },
    ];

    const warrenSteps = [
        {
            icon: '🔨',
            title: 'Welcome, Warren',
            subtitle: 'Your role in the Meng Hub ecosystem',
            body: `As a Warren, you are the human quality gate between AI output and students. The AI is fast but makes mistakes. You catch them.

Your job is not to write content from scratch — the AI does that. Your job is to fact-check, fix errors, verify quiz answer keys, and ensure everything is accurate before students see it.

This takes 5 minutes to read. It\'s worth it.`,
            tip: null,
        },
        {
            icon: '🔁',
            title: 'The Full Pipeline',
            subtitle: 'Where you fit in',
            body: `Here\'s how content gets from a textbook to a student:

1. Admin uploads a PDF in the AI Forge
2. Loop 1 (Gemini) reads the curved-spine scan, fixes OCR
3. Loop 2 (Claude) structures the text into blocks: paragraphs, math, timelines, quizzes, summaries
4. Loop 3 (GPT-4o) audits LaTeX and quiz explanations
5. Blocks land as "pending_review" — admin sees these
6. Admin reviews at /review, approves → blocks become "draft"
7. ← YOU ARE HERE → Warren Job Board shows draft blocks to claim
8. You open the block editor, fact-check, fix if needed, then publish
9. Students see the published block`,
            tip: '💡 You can also help in step 6 — the "Review Assist" tab shows pending blocks you can pre-edit before admin approval.',
        },
        {
            icon: '📋',
            title: 'The Warren Job Board',
            subtitle: '/warren — your home base',
            body: `The Job Board has three tabs:

📋 JOB BOARD — Available blocks that need a Warren. Each shows the block type (quiz, paragraph, math, etc.) and which lesson it belongs to. Click "Claim Task" to assign it to yourself.

🔨 MY TASKS — Your claimed blocks. These are yours until you publish or drop them. Click "✏️ Edit & Publish" to open the block editor.

🔍 REVIEW ASSIST — Blocks awaiting admin approval. You can pre-edit these to save admin time. They still need admin sign-off before appearing on the main job board.`,
            tip: '💡 Don\'t claim more than you can finish. If you need to step away, use "Drop" to release a block back to the job board for another Warren.',
        },
        {
            icon: '✏️',
            title: 'The Block Editor',
            subtitle: 'Your main workspace',
            body: `When you open a claimed block, you get a split-screen:

LEFT SIDE:
• AI Edit — type an instruction ("fix the LaTeX", "rewrite option B", "the answer key is wrong, C should be correct") and the AI surgically edits just what you asked for
• Fact-Check Notes — write what you verified and what you changed. This logs your work.
• Text editor for paragraph/heading blocks
• JSON editor for structured blocks (quizzes, timelines, etc.) with live validation

RIGHT SIDE:
• Live preview — shows exactly what the student will see, updating as you type

At the bottom: "💾 Save Draft" (keep working) or "🚀 Publish" (goes live to students).`,
            tip: '💡 The JSON editor is color-coded green. If it turns red, the JSON is invalid and you cannot publish until you fix it.',
        },
        {
            icon: '🌐',
            title: 'Inserting Concept Links',
            subtitle: 'The Zettelkasten is your responsibility',
            body: `Paragraphs in student notes should have [[concept links]] for key terms. These let students hover to see definitions.

When editing a text block, click "🌐 Insert [[link]]" above the textarea. A concept search appears — type a term and results show with your current class\'s concepts first (⭐).

Click any result to insert [[Treaty of Versailles|uuid]] at your cursor position.

If a concept doesn\'t exist yet, the search shows a "create one →" link that takes you to /concepts where you can make it (or use AI Extract to generate it from the lesson text).`,
            tip: '💡 After publishing a block, use ⌘K search to verify the concept link resolves correctly by searching the term.',
        },
        {
            icon: '⚠️',
            title: 'What to Actually Check',
            subtitle: 'Your specific responsibilities',
            body: `For EVERY block type, verify:
• Is the content factually accurate? (Cross-check against your knowledge or a trusted source)
• Are the math/LaTeX formulas rendering correctly?

For QUIZ blocks specifically:
• Is the correct_index actually correct? The AI makes answer key errors.
• Is the explanation thorough? It should explain WHY the right answer is right AND why each wrong option is wrong.
• Is the hint useful without giving away the answer?

For TIMELINE blocks:
• Are the dates accurate?

For FRQ blocks:
• Is the model answer actually a good response?
• Does the scoring guide reflect real AP rubric logic?

For SUMMARY blocks:
• Are the concept questions genuinely deep? (cause/effect, connections — not simple recall)`,
            tip: '💡 When in doubt about a fact, use the Fact-Check Notes to flag it for admin review rather than publishing something uncertain.',
        },
        {
            icon: '🎉',
            title: 'You\'re Ready to Contribute',
            subtitle: 'Students are counting on you',
            body: `Quick reference:

• Go to /warren to see available jobs
• Claim → Edit & Publish is the main flow
• Use AI Edit for quick fixes, manual edit for precise changes
• Insert [[concept links]] in text blocks
• Write fact-check notes for everything you verify
• When stuck, drop the block — don\'t guess

Your work directly impacts whether students trust this platform. A wrong answer key that ships to students is worse than a slightly delayed one.

Thank you for being part of this.`,
            tip: null,
        },
    ];

    $: steps = role === 'warren' ? warrenSteps : studentSteps;
    let currentStep = 0;
    $: step = steps[currentStep];
    $: isLast = currentStep === steps.length - 1;

    function next() {
        if (!isLast) { currentStep++; }
        else { goto('/'); }
    }

    function prev() { if (currentStep > 0) currentStep--; }

    function skip() { goto('/'); }
</script>

<svelte:head>
    <title>Tutorial — Meng Hub 梦</title>
</svelte:head>

<div class="min-h-screen bg-stars flex flex-col items-center justify-center px-4 py-12 relative overflow-hidden">

    <!-- Ambient glow -->
    <div class="absolute inset-0 pointer-events-none">
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[120px]"></div>
    </div>

    <!-- Progress dots -->
    <div class="flex gap-2 mb-8 relative z-10">
        {#each steps as _, i}
            <button on:click={() => currentStep = i}
                class="transition-all duration-300 rounded-full {i === currentStep ? 'w-8 h-2 bg-blue-400' : i < currentStep ? 'w-2 h-2 bg-blue-600' : 'w-2 h-2 bg-slate-700'}">
            </button>
        {/each}
    </div>

    <!-- Card -->
    {#key currentStep}
        <div class="w-full max-w-2xl relative z-10 bg-slate-900/90 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl overflow-hidden"
            in:fly={{ y: 20, duration: 300 }} out:fade={{ duration: 150 }}>

            <!-- Header -->
            <div class="px-8 pt-10 pb-6 text-center border-b border-white/10">
                <span class="text-5xl block mb-4">{step.icon}</span>
                <p class="text-[10px] font-black uppercase tracking-widest text-blue-400 mb-2">{step.subtitle}</p>
                <h1 class="text-2xl font-black text-white tracking-tight">{step.title}</h1>
            </div>

            <!-- Body -->
            <div class="px-8 py-7">
                <div class="text-slate-300 font-serif text-base leading-relaxed space-y-4">
                    {#each step.body.split('\n\n') as para}
                        <p class="whitespace-pre-line">{para}</p>
                    {/each}
                </div>

                {#if step.tip}
                    <div class="mt-6 p-4 bg-amber-900/30 border border-amber-700/40 rounded-xl">
                        <p class="text-sm text-amber-300 font-serif leading-relaxed">{step.tip}</p>
                    </div>
                {/if}
            </div>

            <!-- Footer -->
            <div class="px-8 pb-8 flex items-center justify-between">
                <div class="flex gap-3">
                    {#if currentStep > 0}
                        <button on:click={prev} class="text-sm font-bold text-slate-500 hover:text-slate-300 transition-colors">← Back</button>
                    {:else}
                        <button on:click={skip} class="text-sm font-bold text-slate-600 hover:text-slate-400 transition-colors">Skip tutorial</button>
                    {/if}
                </div>

                <div class="flex items-center gap-3">
                    <span class="text-xs font-bold text-slate-600">{currentStep + 1} / {steps.length}</span>
                    <button on:click={next}
                        class="px-7 py-3 bg-blue-600 hover:bg-blue-500 text-white font-black text-sm rounded-xl transition-all hover:-translate-y-0.5 shadow-lg shadow-blue-900/50">
                        {isLast ? (role === 'warren' ? 'Start Contributing →' : 'Start Learning →') : 'Next →'}
                    </button>
                </div>
            </div>
        </div>
    {/key}

    <!-- Role indicator -->
    <p class="mt-6 text-xs text-slate-600 font-medium relative z-10 capitalize">
        {role} tutorial · {steps.length} steps
    </p>
</div>
